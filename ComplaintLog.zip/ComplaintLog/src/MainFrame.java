import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class MainFrame extends JFrame {

    public MainFrame() {
        super("Small Buttons Page");

        // Set layout to BorderLayout
        setLayout(new BorderLayout());

        // Panel to hold the buttons
        JPanel buttonPanel = new JPanel(new GridLayout(1, 3, 10, 0)); // 1 row, 3 columns, horizontal gap of 10 pixels
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Add padding

        // Create buttons
        JButton customerButton = new JButton("Customer");
        JButton departmentButton = new JButton("Department");
        JButton adminButton = new JButton("Admin");

        // Set font and size for buttons
        Font buttonFont = new Font("Arial", Font.BOLD, 14); // Decrease font size
        customerButton.setFont(buttonFont);
        departmentButton.setFont(buttonFont);
        adminButton.setFont(buttonFont);

        // Set preferred size for buttons
        Dimension buttonSize = new Dimension(100, 40); // Set desired button size
        customerButton.setPreferredSize(buttonSize);
        departmentButton.setPreferredSize(buttonSize);
        adminButton.setPreferredSize(buttonSize);

        // Set background color for buttons
        customerButton.setBackground(Color.BLUE);
        departmentButton.setBackground(Color.GREEN);
        adminButton.setBackground(Color.RED);

        // Set foreground color (text color) for buttons
        customerButton.setForeground(Color.WHITE);
        departmentButton.setForeground(Color.WHITE);
        adminButton.setForeground(Color.WHITE);

        // Add action listeners to buttons
        customerButton.addActionListener(e -> openCustomerForm());
        departmentButton.addActionListener(e -> openDepartmentForm());
        adminButton.addActionListener(e -> openAdminForm());

        // Add buttons to the panel
        buttonPanel.add(customerButton);
        buttonPanel.add(departmentButton);
        buttonPanel.add(adminButton);

        // Add panel to the center of the frame
        add(buttonPanel, BorderLayout.CENTER);

        // Set frame size and make it visible
        setSize(400, 100); // Adjusted size for smaller buttons
        setLocationRelativeTo(null); // Center the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void openCustomerForm() {
        Customer customerForm = new Customer();
        customerForm.setVisible(true);
    }

    private void openDepartmentForm() {
        // Open department form
        // Add department form creation logic here
    }

    private void openAdminForm() {
        AdminForm adminForm = new AdminForm();
        adminForm.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainFrame::new);
    }
}
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;


class HomeButton extends JButton {
    public HomeButton(String text) {
        super(text);
        addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Hide the customer form and show the main frame
                SwingUtilities.getWindowAncestor((Component)e.getSource()).dispose();
                MainFrame mainFrame = new MainFrame();
                mainFrame.setVisible(true);
            }
        });
    }
}

public class Customer extends JFrame implements ActionListener {

    private JTextField nameField, ageField, dobField, mobileField, addressField;
    private JTextArea complaintTextArea;
    private JButton submitButton;
    private HomeButton homeButton; // Add home button

    private Connection connection;

    public Customer() {
        super("Customer Complaint Form");

        // Initialize database connection (not used in this example)
        // Make sure you have a database setup and replace the connection details accordingly
        String jdbcURL = "jdbc:mysql://localhost:3306/complaints_database";
        String username = "root";
        String password = "Revival064@";
        try {
            connection = DriverManager.getConnection(jdbcURL, username, password);
            System.out.println("Database connection established");
        } catch (SQLException e) {
            e.printStackTrace();
            System.exit(1);
        }

        setupGUI();
    }

    private void setupGUI() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(9, 2, 5, 5)); // Increased rows to accommodate the home button

        JLabel nameLabel = new JLabel("Name:");
        nameField = new JTextField();
        JLabel ageLabel = new JLabel("Age:");
        ageField = new JTextField();
        JLabel dobLabel = new JLabel("Date of Birth (YYYY-MM-DD):");
        dobField = new JTextField();
        JLabel mobileLabel = new JLabel("Mobile Number:");
        mobileField = new JTextField();
        JLabel addressLabel = new JLabel("Address:");
        addressField = new JTextField();
        JLabel complaintLabel = new JLabel("Complaint Description:");
        complaintTextArea = new JTextArea(5, 20);
        JScrollPane scrollPane = new JScrollPane(complaintTextArea);
        submitButton = new JButton("Submit");
        homeButton = new HomeButton("Home"); // Create home button

        add(nameLabel);
        add(nameField);
        add(ageLabel);
        add(ageField);
        add(dobLabel);
        add(dobField);
        add(mobileLabel);
        add(mobileField);
        add(addressLabel);
        add(addressField);
        add(complaintLabel);
        add(scrollPane);
        add(new JLabel());
        add(submitButton);
        add(new JLabel());
        add(homeButton); // Add home button

        submitButton.addActionListener(this);
        homeButton.addActionListener(this); // Add action listener to home button

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submitButton) {
            submitComplaint();
        }
    }

    private void submitComplaint() {
        String name = nameField.getText();
        int age = Integer.parseInt(ageField.getText());
        String dob = dobField.getText();
        String mobile = mobileField.getText();
        String address = addressField.getText();
        String complaint = complaintTextArea.getText();

        try {
            String query = "INSERT INTO customer_complaints (name, age, dob, mobile, address, complaint) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, name);
            preparedStatement.setInt(2, age);
            preparedStatement.setString(3, dob);
            preparedStatement.setString(4, mobile);
            preparedStatement.setString(5, address);
            preparedStatement.setString(6, complaint);
            preparedStatement.executeUpdate();
            JOptionPane.showMessageDialog(this, "Complaint submitted successfully!");
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error submitting complaint!");
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(Customer::new);
    }
}

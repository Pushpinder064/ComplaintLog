//import javax.swing.*;
//import java.awt.*;
//import java.sql.*;
//import java.util.Vector;
//import javax.swing.table.DefaultTableModel;
//
//
//public class AdminForm extends JFrame {
//
//    private JTable dataTable;
//
//    public AdminForm() {
//        super("Admin Complaint Viewer");
//
//        // Set layout to BorderLayout
//        setLayout(new BorderLayout());
//
//        // Create table model
//        DefaultTableModel tableModel = new DefaultTableModel();
//
//        // Add columns to table model
//        tableModel.addColumn("ID");
//        tableModel.addColumn("Name");
//        tableModel.addColumn("Age");
//        tableModel.addColumn("DOB");
//        tableModel.addColumn("Mobile");
//        tableModel.addColumn("Address");
//        tableModel.addColumn("Complaint");
//
//        // Create table with default table model
//        dataTable = new JTable(tableModel);
//
//        // Add table to scroll pane
//        JScrollPane scrollPane = new JScrollPane(dataTable);
//
//        // Add scroll pane to frame
//        add(scrollPane, BorderLayout.CENTER);
//
//        // Set frame size and make it visible
//        setSize(800, 600);
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        setVisible(true);
//
//        // Populate table with complaint data
//        populateTable();
//    }
//
//    private void populateTable() {
//        // Database connection details
//        String jdbcURL = "jdbc:mysql://localhost:3306/complaints_database";
//        String username = "root";
//        String password = "Revival064@";
//
//        try (Connection connection = DriverManager.getConnection(jdbcURL, username, password)) {
//            String query = "SELECT * FROM customer_complaints";
//            PreparedStatement preparedStatement = connection.prepareStatement(query);
//            ResultSet resultSet = preparedStatement.executeQuery();
//
//            // Loop through the result set and add rows to the table model
//            while (resultSet.next()) {
//                Vector<Object> rowData = new Vector<>();
//                rowData.add(resultSet.getInt("id"));
//                rowData.add(resultSet.getString("name"));
//                rowData.add(resultSet.getInt("age"));
//                rowData.add(resultSet.getString("dob"));
//                rowData.add(resultSet.getString("mobile"));
//                rowData.add(resultSet.getString("address"));
//                rowData.add(resultSet.getString("complaint"));
//                ((DefaultTableModel) dataTable.getModel()).addRow(rowData);
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//            JOptionPane.showMessageDialog(this, "Error retrieving complaint data from database!");
//        }
//    }
//
//    public static void main(String[] args) {
//        SwingUtilities.invokeLater(AdminForm::new);
//    }
//}
////import javax.swing.*;
////import javax.swing.table.DefaultTableModel;
////import java.awt.*;
////import java.awt.event.*;
////import java.sql.*;
////import java.util.Vector;
////
////public class AdminForm extends JFrame {
////
////    private JTable dataTable;
////
////    public AdminForm() {
////        super("Admin Complaint Viewer");
////
////        // Set layout to BorderLayout
////        setLayout(new BorderLayout());
////
////        // Create table model
////        DefaultTableModel tableModel = new DefaultTableModel() {
////            @Override
////            public Class<?> getColumnClass(int columnIndex) {
////                // Return Boolean class for the column where checkboxes will be added
////                if (columnIndex == 7) {
////                    return Boolean.class;
////                }
////                return super.getColumnClass(columnIndex);
////            }
////        };
////
////        // Add columns to table model
////        tableModel.addColumn("ID");
////        tableModel.addColumn("Name");
////        tableModel.addColumn("Age");
////        tableModel.addColumn("DOB");
////        tableModel.addColumn("Mobile");
////        tableModel.addColumn("Address");
////        tableModel.addColumn("Complaint");
////        tableModel.addColumn("Resolved");
////
////        // Create table with default table model
////        dataTable = new JTable(tableModel);
////
////        // Add table to scroll pane
////        JScrollPane scrollPane = new JScrollPane(dataTable);
////
////        // Add scroll pane to frame
////        add(scrollPane, BorderLayout.CENTER);
////
////        // Set frame size and make it visible
////        setSize(800, 600);
////        setLocationRelativeTo(null);
////        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
////        setVisible(true);
////
////        // Populate table with complaint data
////        populateTable();
////    }
////
////    private void populateTable() {
////        // Database connection details
////        String jdbcURL = "jdbc:mysql://localhost:3306/complaints_database";
////        String username = "root";
////        String password = "Revival064@";
////
////        try (Connection connection = DriverManager.getConnection(jdbcURL, username, password)) {
////            String query = "SELECT * FROM customer_complaints";
////            try (PreparedStatement preparedStatement = connection.prepareStatement(query);
////                 ResultSet resultSet = preparedStatement.executeQuery()) {
////
////                // Loop through the result set and add rows to the table model
////                while (resultSet.next()) {
////                    Vector<Object> rowData = new Vector<>();
////                    rowData.add(resultSet.getInt("id"));
////                    rowData.add(resultSet.getString("name"));
////                    rowData.add(resultSet.getInt("age"));
////                    rowData.add(resultSet.getString("dob"));
////                    rowData.add(resultSet.getString("mobile"));
////                    rowData.add(resultSet.getString("address"));
////                    rowData.add(resultSet.getString("complaint"));
////
////                    // Create a checkbox for each row
////                    JCheckBox resolvedCheckbox = new JCheckBox();
////                    rowData.add(resolvedCheckbox);
////
////                    ((DefaultTableModel) dataTable.getModel()).addRow(rowData);
////                }
////            }
////        } catch (SQLException e) {
////            e.printStackTrace();
////            JOptionPane.showMessageDialog(this, "Error retrieving complaint data from database!");
////        }
////    }
////
////    public static void main(String[] args) {
////        SwingUtilities.invokeLater(AdminForm::new);
////    }
////}
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;

class HomeButton2 extends JButton {
    public HomeButton2(String text) {
        super(text);
        addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Hide the admin form and show the main frame
                SwingUtilities.getWindowAncestor((Component)e.getSource()).dispose();
                MainFrame mainFrame = new MainFrame();
                mainFrame.setVisible(true);
            }
        });
    }
}

public class AdminForm extends JFrame {

    private JTable dataTable;

    public AdminForm() {
        super("Admin Complaint Viewer");

        // Set layout to BorderLayout
        setLayout(new BorderLayout());

        // Create table model
        DefaultTableModel tableModel = new DefaultTableModel();

        // Add columns to table model
        tableModel.addColumn("ID");
        tableModel.addColumn("Name");
        tableModel.addColumn("Age");
        tableModel.addColumn("DOB");
        tableModel.addColumn("Mobile");
        tableModel.addColumn("Address");
        tableModel.addColumn("Complaint");

        // Create table with default table model
        dataTable = new JTable(tableModel);

        // Add table to scroll pane
        JScrollPane scrollPane = new JScrollPane(dataTable);

        // Add scroll pane to frame
        add(scrollPane, BorderLayout.CENTER);

        // Create and add home button
        HomeButton homeButton = new HomeButton("Home");
        add(homeButton, BorderLayout.SOUTH);

        // Set frame size and make it visible
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        // Populate table with complaint data
        populateTable();
    }

    private void populateTable() {
        // Database connection details
        String jdbcURL = "jdbc:mysql://localhost:3306/complaints_database";
        String username = "root";
        String password = "Revival064@";

        try (Connection connection = DriverManager.getConnection(jdbcURL, username, password)) {
            String query = "SELECT * FROM customer_complaints";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            // Loop through the result set and add rows to the table model
            while (resultSet.next()) {
                Vector<Object> rowData = new Vector<>();
                rowData.add(resultSet.getInt("id"));
                rowData.add(resultSet.getString("name"));
                rowData.add(resultSet.getInt("age"));
                rowData.add(resultSet.getString("dob"));
                rowData.add(resultSet.getString("mobile"));
                rowData.add(resultSet.getString("address"));
                rowData.add(resultSet.getString("complaint"));
                ((DefaultTableModel) dataTable.getModel()).addRow(rowData);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error retrieving complaint data from database!");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AdminForm::new);
    }
}
